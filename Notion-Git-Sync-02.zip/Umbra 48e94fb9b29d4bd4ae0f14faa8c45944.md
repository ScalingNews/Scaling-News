# Umbra

Category: Privacy Payment
Rating Index: ⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One, OP Mainnet
Link | Click the Link Text: https://twitter.com/UmbraCash   https://discord.com/invite/uw4y5J2p7C   https://app.umbra.cash/
Investor: Gitcoin Beta Round
List: Wallet