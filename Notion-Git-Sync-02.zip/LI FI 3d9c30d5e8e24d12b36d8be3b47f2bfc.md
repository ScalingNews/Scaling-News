# LI.FI

Category: CrossChain Aggregator
Rating Index: ⭐️⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One, Linea, OP Mainnet, Scroll
Link | Click the Link Text: https://twitter.com/lifiprotocol   https://discord.com/invite/lifi   https://jumper.exchange/
 Raised: $ 23M
Investor: 1kx, Bloccelerate, CoinFund, Coinbase, Dragonfly Capital, Factor, Lattice Capital, Scalar Capital, Superscrypt, Theta
List: Bridge