# Swapsicle

Category: MultiChain AMM, Perpetual Market
Rating Index: ⭐️⭐️⭐️
Ecosystem: Arbitrum One
Link | Click the Link Text: https://twitter.com/SwapsicleDEX   https://discord.com/invite/6UxVtUS4F8  https://www.swapsicle.io/
List: DEX