# Bounce

Category: LBP Platform
Rating Index: ⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One, Polygon zkEVM, Scroll, zkSync Era
Link | Click the Link Text: https://twitter.com/bounce_finance   https://t.me/bounce_finance   https://www.bounce.finance/
Investor: Blockchain Capital, Coinbase, DHVC, Hashed, Pantera Capital, SNZ Holding
Token: AUCTION
List: DeFi