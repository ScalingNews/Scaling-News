# Openleverage

Category: Leverage Market
Rating Index: ⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One, Scroll
Link | Click the Link Text: https://twitter.com/OpenLeverage   https://discord.com/invite/openleverage   https://openleverage.finance/
Investor: Binance Labs, Continue Capital, Crypto.com, FBG Capital, LD Capital, Signum Capital, YBB Foundation
Token: OLE
List: DEX