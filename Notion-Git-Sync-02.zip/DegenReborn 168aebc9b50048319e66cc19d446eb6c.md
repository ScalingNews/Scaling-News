# DegenReborn

Category: Fully Onchain Game
Rating Index: ⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One, Linea, Opside
Link | Click the Link Text: https://twitter.com/DegenReborn   https://t.me/DegenRebornCommunity   https://degenreborn.xyz/
Investor: CyberConnect, Era7, Galxe
List: Game