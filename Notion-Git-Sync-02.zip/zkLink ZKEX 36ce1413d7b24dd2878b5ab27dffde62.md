# zkLink/ZKEX

Category: Orderbook DEX
Rating Index: ⭐️⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One, Base, Linea, Mantle, OP Mainnet, Polygon zkEVM, Scroll, Starknet, Taiko, zkSync Era
Link | Click the Link Text: https://twitter.com/ZKEX_Official   https://discord.com/invite/ctDAYrrNTH   https://zkex.com/
 Raised: $ 18.5M
Investor: Ascensive Assets, Big Brain Holdings, Coinbase, Efficient Frontier, SIG DTI
List: DEX