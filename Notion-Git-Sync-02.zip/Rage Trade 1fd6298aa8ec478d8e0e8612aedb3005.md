# Rage Trade

Category: Perpetual Market
Rating Index: ⭐️⭐️⭐️
Ecosystem: Arbitrum One, LayerZero
Link | Click the Link Text: https://twitter.com/rage_trade   http://discord.gg/8sBqJ5Qc3Q   https://www.rage.trade/
List: DEX