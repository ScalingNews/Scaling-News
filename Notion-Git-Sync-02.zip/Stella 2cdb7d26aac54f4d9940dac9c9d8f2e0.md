# Stella

Category: Leveragedd Lending
Rating Index: ⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One
Link | Click the Link Text: https://twitter.com/stellaxyz_   https://discord.com/invite/BcVquv4DMR   https://stellaxyz.io/
 Raised: $ 1.6M
Investor: Binance Labs, DeFiance Capital, Delphi Digital, Multicoin, Spartan Group
Token: ALPHA
List: DeFi