# UnlockProtocol

Category: DAO Tool
Rating Index: ⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One, Base, OP Mainnet
Link | Click the Link Text: https://twitter.com/UnlockProtocol   https://discord.com/invite/kQv8HZXRCp   https://unlock-protocol.com/
 Raised: $ 5.7M
Investor: Coinbase, ConsenSys Mesh
Token: UDT
List: Infra