# Flashbots Suave

> **RaaS Framework**
> 

[Arbitrum Orbit](Arbitrum%20Orbit%20e21bddc4d495401b830819fe3e8e1000.md)

[**Rollkit**](https://www.notion.so/Rollkit-1659ae96b3224453a23e14e9c5995779?pvs=21)

[**Fuel**](Fuel%2010ef831a877f49659a8b419d401c8bac.md)

[**EigenLayer**](EigenLayer%202228903b7d524a8ca8a4795d17701ad2.md)

[**Celestia**](Celestia%20b9a3141a8c1149fe8270f256f6b8f886.md)

[**Avail**](Avail%20ddc337c43f0d41c595d27d3b4b08b601.md)

[**Sovereign**](Sovereign%20ec44ae62787c4a21ba554956dc9b6133.md)

[**ZK Stack**](ZK%20Stack%208fb4a1260d884513bff0a0b6c70b964b.md)

[**Starknet Slush**](https://www.notion.so/Starknet-Slush-7212a617285843c9ae3ce21826fbe29c?pvs=21)

[**Stackr**](https://www.notion.so/Stackr-c629fca3105e4457921c9cb29e80319b?pvs=21)

[**Cartesi**](Cartesi%20a5dc22f1cf334601851bd4b301a59651.md)

[**Opside**](Opside%205f8ef2be16eb4351937f16b7926746ff.md)

[**Berachain**](https://www.notion.so/Berachain-68b60a65f5e342cabef2b82d863095b1?pvs=21)

> **No-Code Deployment**
> 

[**Eclipse**](Eclipse%202e7660ff2c764c429ce7b0814761686b.md)

[**AltLayer**](AltLayer%207671ad3cb13040a69b91ebba9386d6ae.md)

[**Caldera**](Caldera%20dab5daeb91414d34a43e11e7904068c9.md)

[**Conduit**](Conduit%200bf36a8c9c984d07943ec93d5c129d78.md)

[**Artesi**](https://www.notion.so/Artesi-96d66c36866f47d3b6cc883ddc1ca135?pvs=21)

> **Shared Sequencer**
> 

[OP Stack](OP%20Stack%20a0c4bad98dc042db87272cf107a9f17c.md)

[**Dymension**](Dymension%20fca81017f6a64d1fac362e6f56e990bd.md)

[**Espresso**](Espresso%20423bd9cb0bc44028a4e0a3bbb3ec0e2b.md)

[**Flashbots Suave**](Flashbots%20Suave%20bdcb0bb65efa4199a7845e1fe015ef36.md)

[**Saga**](Saga%20174dca18819e485b8b31d8e0c014a472.md)

### **Flashbots Suave Ecosystem**

[`Website`](https://writings.flashbots.net/the-future-of-mev-is-suave/)   [`Twitter`](https://twitter.com/metachris)   [`Discord`](https://discord.com/invite/flashbots)   [`Github`](https://github.com/flashbots)

**An overview of the Projects in the Flashbots Suave ecosystem.**

[**Analysis**](Flashbots%20Suave%20c536abf20a464414b613382a32ab3d81.md)   [**All](All%20b52771c4934a425494855ba551de9a8e.md)   [Wallet](Wallet%20a982282f98984322ad4b944652defc4c.md)   [Bridge](Bridge%20f25600f9633c413ea6787ffc51c7d165.md)   [DEX](DEX%20afd4c15032354c8a90cbf345ffac7833.md)   [DeFi](DeFi%207bee666e8875434da57b1ffa2ffb5a47.md)   [NFT Trade](NFT%20Trade%200ddd4f5347f1406bb767e619419ddfe1.md)   [NFT](NFT%20f4fa71654d294435ba70236cf1e819fb.md)   [Game](Game%209bfeea3aa9634d889f95a9297b217f5d.md)   [Social](Social%2007e16f6ebbfc4d83ae39d6494cf1d153.md)   [Infra Tool](Infra%20Tool%2062f587faf5d74c559900d1bd69db7afc.md)**

### Description

TBD

### **State Vali**dation

- **TBD**
TBD
    
    `TBD`
    
- **TBD**
- **TBD**

### Data Availability

- **On chain
Ethereum DA**

### Upgradeability

- **TBD**
    
    `TBD`
    

### Operator

- **Single Sequencer (existing)**
    - **Censorship Resistance**
    Users can force any transaction: Allows the users to circumvent censorship by interacting with the smart contract directly.
    - **Sequencer Failure: Transact using Layer1**
    If the primary sequencer goes down, the user is able to submit a transaction through Layer1 and force its inclusion on Layer2.
    
    **`MEV can be extracted if the operator exploits their centralized position and frontruns user transactions.`**
    
- **TBD**

### Environments

- **Ethereum VM**

### Technical Decentralization

- **TBD**
    - **TBD**
        
        TBD
        
    - **TBD**
        
        TBD
        
- **TBD**
    - **TBD**
    TBD
    - **TBD**
    TBD
    - **TBD**
    TBD
    ****

[All](All%20b52771c4934a425494855ba551de9a8e.md)

[Wallet](Wallet%20a982282f98984322ad4b944652defc4c.md)

[Bridge](Bridge%20f25600f9633c413ea6787ffc51c7d165.md)

[DEX](DEX%20afd4c15032354c8a90cbf345ffac7833.md)

[DeFi](DeFi%207bee666e8875434da57b1ffa2ffb5a47.md)

[NFT Trade](NFT%20Trade%200ddd4f5347f1406bb767e619419ddfe1.md)

[NFT](NFT%20f4fa71654d294435ba70236cf1e819fb.md)

[Game](Game%209bfeea3aa9634d889f95a9297b217f5d.md)

[Social](Social%2007e16f6ebbfc4d83ae39d6494cf1d153.md)

[Infra Tool](Infra%20Tool%2062f587faf5d74c559900d1bd69db7afc.md)