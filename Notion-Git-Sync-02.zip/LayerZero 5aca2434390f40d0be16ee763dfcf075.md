# LayerZero

Category: CrossChain SDK
Rating Index: ⭐️⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One, Base, Linea, OP Mainnet, Polygon zkEVM, Scroll, zkSync Era
Link | Click the Link Text: https://twitter.com/LayerZero_Labs   https://discord-layerzero.netlify.app/discord   https://layerzero.network/
 Raised: $ 261M
Investor: Animoca Brands, Avalanche, Binance Labs, Bixin Ventures, Circle Ventures, CoinFund, Coinbase, Dapper Labs, DeFiance Capital, Delphi Digital, FTX, Fantom, GenBlock Capital, Hypersphere, IOBC Capital, Lightspeed Venture, Matrixport, Multicoin, NGC Ventures, OKX Ventures, OpenSea, PayPal, Polygon Ventures, Robot Ventures, Samsung, Sequoia Capital, Sino Global, Spartan Group, Tiger Global, Uniswap, a16z, imToken
List: Infra