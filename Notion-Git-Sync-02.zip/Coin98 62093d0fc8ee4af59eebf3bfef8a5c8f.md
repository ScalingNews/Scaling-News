# Coin98

Category: Extension Wallet, Mobile Wallet
Rating Index: ⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One, OP Mainnet, Polygon zkEVM, Taiko, zkSync Era
Link | Click the Link Text: https://twitter.com/coin98_wallet   https://discord.com/invite/ytkeARXYu9   http://coin98.com
Token: C98
List: Wallet