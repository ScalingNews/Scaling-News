# Predy finance

Category: Perpetual Market
Rating Index: ⭐️⭐️
Ecosystem: Arbitrum One
Link | Click the Link Text: https://twitter.com/predyfinance   https://discord.com/invite/predy   https://www.predy.finance/predy3/
List: DEX