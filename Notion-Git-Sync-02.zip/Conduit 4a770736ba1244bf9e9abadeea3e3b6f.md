# Conduit

> **RaaS Framework**
> 

[Arbitrum Orbit](Arbitrum%20Orbit%20e21bddc4d495401b830819fe3e8e1000.md)

[**Rollkit**](https://www.notion.so/Rollkit-1659ae96b3224453a23e14e9c5995779?pvs=21)

[**Fuel**](Fuel%2010ef831a877f49659a8b419d401c8bac.md)

[**EigenLayer**](EigenLayer%202228903b7d524a8ca8a4795d17701ad2.md)

[**Celestia**](Celestia%20b9a3141a8c1149fe8270f256f6b8f886.md)

[**Avail**](Avail%20ddc337c43f0d41c595d27d3b4b08b601.md)

[**Sovereign**](Sovereign%20ec44ae62787c4a21ba554956dc9b6133.md)

[**ZK Stack**](ZK%20Stack%208fb4a1260d884513bff0a0b6c70b964b.md)

[**Starknet Slush**](https://www.notion.so/Starknet-Slush-7212a617285843c9ae3ce21826fbe29c?pvs=21)

[**Stackr**](https://www.notion.so/Stackr-c629fca3105e4457921c9cb29e80319b?pvs=21)

[**Cartesi**](Cartesi%20a5dc22f1cf334601851bd4b301a59651.md)

[**Opside**](Opside%205f8ef2be16eb4351937f16b7926746ff.md)

[**Berachain**](https://www.notion.so/Berachain-68b60a65f5e342cabef2b82d863095b1?pvs=21)

> **No-Code Deployment**
> 

[**Eclipse**](Eclipse%202e7660ff2c764c429ce7b0814761686b.md)

[**AltLayer**](AltLayer%207671ad3cb13040a69b91ebba9386d6ae.md)

[**Caldera**](Caldera%20dab5daeb91414d34a43e11e7904068c9.md)

[**Conduit**](Conduit%200bf36a8c9c984d07943ec93d5c129d78.md)

[**Artesi**](https://www.notion.so/Artesi-96d66c36866f47d3b6cc883ddc1ca135?pvs=21)

> **Shared Sequencer**
> 

[OP Stack](OP%20Stack%20a0c4bad98dc042db87272cf107a9f17c.md)

[**Dymension**](Dymension%20fca81017f6a64d1fac362e6f56e990bd.md)

[**Espresso**](Espresso%20423bd9cb0bc44028a4e0a3bbb3ec0e2b.md)

[**Flashbots Suave**](Flashbots%20Suave%20bdcb0bb65efa4199a7845e1fe015ef36.md)

[**Saga**](Saga%20174dca18819e485b8b31d8e0c014a472.md)

### **Conduit Ecosystem**

[`Website`](https://conduit.xyz/)   [`Twitter`](https://twitter.com/conduitxyz)   [`Discord`](https://discord.com/invite/X5Yn3NzVRh)

**An overview of the Projects in the Conduit ecosystem.**

[**Analysis**](Conduit%204a770736ba1244bf9e9abadeea3e3b6f.md)   [**All](All%209c2cf55029a747318220cf6b92e3d356.md)   [Wallet](Wallet%205505d25e562c4e47a132cb4374d02173.md)   [Bridge](Bridge%20c346327a2e6645a9953b509742c3f2a5.md)   [DEX](DEX%20a7c8208c929d4c7095cb45c2f29b035c.md)   [DeFi](DeFi%2030deae45273649a89ff5d65440e5da3e.md)   [NFT Trade](NFT%20Trade%209bbc667657674b478434f7d6d6454d14.md)   [NFT](NFT%204603d2208a5d4e1686fc13cc99d438b3.md)   [Game](Game%20f8f3daf3ccb9428ba51e60e3ef6fe46f.md)   [Social](Social%2025fb58a94da74e7ba7f9627c0f721c54.md)   [Infra Tool](Infra%20Tool%20f70656c5d0c646508e1ca219939ca5d2.md)**

### Description

TBD

### **State Vali**dation

- **TBD**
TBD
    
    `TBD`
    
- **TBD**
- **TBD**

### Data Availability

- **On chain
Ethereum DA**

### Upgradeability

- **TBD**
    
    `TBD`
    

### Operator

- **Single Sequencer (existing)**
    - **Censorship Resistance**
    Users can force any transaction: Allows the users to circumvent censorship by interacting with the smart contract directly.
    - **Sequencer Failure: Transact using Layer1**
    If the primary sequencer goes down, the user is able to submit a transaction through Layer1 and force its inclusion on Layer2.
    
    **`MEV can be extracted if the operator exploits their centralized position and frontruns user transactions.`**
    
- **TBD**

### Environments

- **Ethereum VM**

### Technical Decentralization

- **TBD**
    - **TBD**
        
        TBD
        
    - **TBD**
        
        TBD
        
- **TBD**
    - **TBD**
    TBD
    - **TBD**
    TBD
    - **TBD**
    TBD
    ****

[All](All%209c2cf55029a747318220cf6b92e3d356.md)

[Wallet](Wallet%205505d25e562c4e47a132cb4374d02173.md)

[Bridge](Bridge%20c346327a2e6645a9953b509742c3f2a5.md)

[DEX](DEX%20a7c8208c929d4c7095cb45c2f29b035c.md)

[DeFi](DeFi%2030deae45273649a89ff5d65440e5da3e.md)

[NFT Trade](NFT%20Trade%209bbc667657674b478434f7d6d6454d14.md)

[NFT](NFT%204603d2208a5d4e1686fc13cc99d438b3.md)

[Game](Game%20f8f3daf3ccb9428ba51e60e3ef6fe46f.md)

[Social](Social%2025fb58a94da74e7ba7f9627c0f721c54.md)

[Infra Tool](Infra%20Tool%20f70656c5d0c646508e1ca219939ca5d2.md)