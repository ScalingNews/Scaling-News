# Pontem

Category: CrossChain Bridge
Rating Index: ⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One, LayerZero, OP Mainnet
Link | Click the Link Text: https://twitter.com/PontemNetwork   http://discord.gg/44QgPFHYqs   https://bridge.liquidswap.com/
 Raised: $ 4.5M
Investor: Alameda, Animoca Brands, Collider, Delphi Digital
List: Bridge