# Magnate

Category: Lending
Rating Index: ⭐️⭐️⭐️
Ecosystem: Arbitrum One, Base
Link | Click the Link Text: https://twitter.com/MagnateFi   https://discord.com/invite/tdaUm4fT   https://www.magnate.finance/
List: DeFi