# Perennial

Category: Leverage Market, Perpetual Market
Rating Index: ⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One, Base
Link | Click the Link Text: https://twitter.com/perenniallabs   https://discord.com/invite/n6ejatX5Rw   https://perennial.finance/
 Raised: $ 12M
Investor: Coinbase, Polychain, Robot Ventures, Variant Fund
List: DEX