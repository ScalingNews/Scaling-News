# B.Protocol

Category: Oracle
Rating Index: ⭐️⭐️⭐️
Ecosystem: Arbitrum One
Link | Click the Link Text: https://twitter.com/bprotocoleth   https://discord.com/invite/bJ4guuw   https://www.bprotocol.org/
List: Infra