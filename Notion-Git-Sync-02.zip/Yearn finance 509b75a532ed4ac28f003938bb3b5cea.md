# Yearn finance

Category: Yield Aggregator
Rating Index: ⭐️⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One, Base, OP Mainnet
Link | Click the Link Text: https://twitter.com/yearnfi   https://discord.com/invite/6PNv2nF   https://yearn.finance/#/home
Token: YFI
List: DeFi