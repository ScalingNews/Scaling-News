# Kanpai Pandas

Category: NFT
Rating Index: ⭐️⭐️⭐️
Ecosystem: Arbitrum One
Link | Click the Link Text: https://twitter.com/kanpaipandas   https://discord.com/invite/EZkkYfWZPE   https://kanpaipandas.io/
List: NFT