# Atomic Green

Category: Perpetual Market
Rating Index: ⭐️⭐️
Ecosystem: Arbitrum One
Link | Click the Link Text: https://twitter.com/atomic__green   https://discord.com/invite/RnhR5mSzea   https://atomic.green/
List: DEX