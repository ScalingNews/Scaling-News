# LayerZero

[Home](Home%200fa15875201546f8a9b01325ff140d18.md)

> **Optimistic Rollup**
> 

[Arbitrum One](Arbitrum%20One%20ce4ba330b3754cc990971b697cee11d9.md)

[OP Mainnet](OP%20Mainnet%20628cfc3d05684e718e96a55b2d28bd7b.md)

[Base](Base%20f996fd055cb64dd395e4516b0bc2203b.md)

[opBNB](opBNB%20de7ac57825ef41d1aa13764c0da7821a.md)

[**Mantle**](Mantle%20bd64bd0cd6ab4d39bd846a2fc9bd812d.md)

[**Fuel**](Fuel%2010ef831a877f49659a8b419d401c8bac.md)

> **ZK Rollup**
> 

[Starknet](Starknet%2085f47becc3ed4435b04cc71b6d7724c3.md)

[zkSync Era](zkSync%20Era%20edc4e9a556134d7bb3cee488988245c3.md)

[Linea](Linea%20d825d6e74e4a40e4aa5d469f3ddfc6fa.md)

[Polygon zkEVM](Polygon%20zkEVM%20d90c0b20a7d4421f98e820ff403fab96.md)

[Scroll](Scroll%20ee3c2c9f55be4c9cb766371dfbc7296d.md)

[Taiko](Taiko%20b99ce7b2c8d64fff91524780b1788d28.md)

> **RaaS Framework**
> 

[OP Stack](OP%20Stack%20a0c4bad98dc042db87272cf107a9f17c.md)

[Arbitrum Orbit](Arbitrum%20Orbit%20e21bddc4d495401b830819fe3e8e1000.md)

[**ZK Stack**](ZK%20Stack%208fb4a1260d884513bff0a0b6c70b964b.md)

[**Celestia**](Celestia%20b9a3141a8c1149fe8270f256f6b8f886.md)

[**Avail**](Avail%20ddc337c43f0d41c595d27d3b4b08b601.md)

[**Sovereign**](Sovereign%20ec44ae62787c4a21ba554956dc9b6133.md)

> **No Code Deployment**
> 

[**Eclipse**](Eclipse%202e7660ff2c764c429ce7b0814761686b.md)

[**Opside**](Opside%205f8ef2be16eb4351937f16b7926746ff.md)

[**AltLayer**](AltLayer%207671ad3cb13040a69b91ebba9386d6ae.md)

[**Cartesi**](Cartesi%20a5dc22f1cf334601851bd4b301a59651.md)

[**Caldera**](Caldera%20dab5daeb91414d34a43e11e7904068c9.md)

[**Conduit**](Conduit%200bf36a8c9c984d07943ec93d5c129d78.md)

> **Shared Sequencer**
> 

[**EigenLayer**](EigenLayer%202228903b7d524a8ca8a4795d17701ad2.md)

[**Flashbots Suave**](Flashbots%20Suave%20bdcb0bb65efa4199a7845e1fe015ef36.md)

[**Espresso**](Espresso%20423bd9cb0bc44028a4e0a3bbb3ec0e2b.md)

[**Dymension**](Dymension%20fca81017f6a64d1fac362e6f56e990bd.md)

[**Saga**](Saga%20174dca18819e485b8b31d8e0c014a472.md)

### LayerZero **Ecosystem**

[`Website`](https://layerzero.network/)   [`Twitter`](https://twitter.com/LayerZero_Labs)   [`Discord`](https://discord-layerzero.netlify.app/discord)   [`Github`](https://github.com/LayerZero-Labs)   [`Block Explorer`](https://layerzeroscan.com/)

**An overview of the Projects in the LayerZero ecosystem.**

[**All](LayerZero%20fb68c5bd8d124080bf9c30a903ee03f8.md)   [Wallet](Wallet%2010e3ec901fd248f29a464d843ab7e518.md)   [Bridge](Bridge%201ae50118c1a54982aa52b2c5044ef195.md)   [DEX](DEX%20c92c69a2933b4c9fb0d7f49fa6934ad1.md)   [DeFi](DeFi%208314544e266945b18435385c386696fe.md)   [NFT Trade](NFT%20Trade%20423f434c50c54bdf99ae9942565345f1.md)   [NFT](NFT%2079d4b5c39c174a8facc536b72c315591.md)   [Game](Game%20ac03660ee5dd4cd094b11ea817799ebf.md)   [Social](Social%2087978cb0754e418da3bc0e042ec438d2.md)   [Infra Tool](Infra%20Tool%20a73ae984884449b9b0e43c2059115c7c.md)**

[无标题](%E6%97%A0%E6%A0%87%E9%A2%98%2039fb86e6a287478691412b415322cb93.csv)

[Wallet](Wallet%2010e3ec901fd248f29a464d843ab7e518.md)

[Bridge](Bridge%201ae50118c1a54982aa52b2c5044ef195.md)

[DEX](DEX%20c92c69a2933b4c9fb0d7f49fa6934ad1.md)

[DeFi](DeFi%208314544e266945b18435385c386696fe.md)

[NFT Trade](NFT%20Trade%20423f434c50c54bdf99ae9942565345f1.md)

[NFT](NFT%2079d4b5c39c174a8facc536b72c315591.md)

[Game](Game%20ac03660ee5dd4cd094b11ea817799ebf.md)

[Social](Social%2087978cb0754e418da3bc0e042ec438d2.md)

[Infra Tool](Infra%20Tool%20a73ae984884449b9b0e43c2059115c7c.md)