# Nexter

Category: Prediction Market
Rating Index: ⭐️⭐️⭐️
Ecosystem: Arbitrum One, Polygon zkEVM, zkSync Era
Link | Click the Link Text: https://twitter.com/NexterDotFi   https://discord.com/invite/9Vd3FTxKu8   https://app.nexter.fi/
List: DEX