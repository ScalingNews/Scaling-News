# Pickle Finance

Category: Yield Optimizer
Rating Index: ⭐️⭐️⭐️
Ecosystem: Arbitrum One, OP Mainnet
Link | Click the Link Text: https://twitter.com/picklefinance   https://discord.com/invite/uG6WhYkM8n   https://www.pickle.finance/zh-CN
Token: PICKLE
List: DeFi