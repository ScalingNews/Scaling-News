# TokenPocket

Category: Hardware Wallet, Mobile Wallet
Rating Index: ⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum Nova, Arbitrum One, Base, OP Mainnet, zkSync Era, zkSync Lite
Link | Click the Link Text: https://twitter.com/TokenPocket_TP   https://discord.com/invite/NKPM8TXFQk   https://www.tokenpocket.pro/
Token: TPT
List: Wallet