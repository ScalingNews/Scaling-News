# Zerion

Category: Portfolio Dashboard, Smart Contract Wallet, Social Recovery Wallet
Rating Index: ⭐️⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One, OP Mainnet, zkSync Era, zkSync Lite
Link | Click the Link Text: https://twitter.com/zerion   https://zerion.io/discord   https://zerion.io/
 Raised: $ 12M
Investor: Alchemy, Coinbase, Mosaic, Wintermute
List: Wallet