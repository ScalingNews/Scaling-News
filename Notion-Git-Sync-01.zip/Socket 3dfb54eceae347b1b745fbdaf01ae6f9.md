# Socket

Category: CrossChain SDK
Rating Index: ⭐️⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One, Base, OP Mainnet, zkSync Era
Link | Click the Link Text: https://twitter.com/socketdottech   https://discord.com/invite/zfKJR8yWaH   https://www.socket.tech/
 Raised: $ 12M
Investor:  LongHash Ventures, Archetype, CoinFund, Coinbase, Framework, Lightspeed Venture, Maven 11, OpenSea
List: Infra