# Eclipse

> **RaaS Framework**
> 

[Arbitrum Orbit](Arbitrum%20Orbit%20e21bddc4d495401b830819fe3e8e1000.md)

[**Rollkit**](https://www.notion.so/Rollkit-1659ae96b3224453a23e14e9c5995779?pvs=21)

[**Fuel**](Fuel%2010ef831a877f49659a8b419d401c8bac.md)

[**EigenLayer**](EigenLayer%202228903b7d524a8ca8a4795d17701ad2.md)

[**Celestia**](Celestia%20b9a3141a8c1149fe8270f256f6b8f886.md)

[**Avail**](Avail%20ddc337c43f0d41c595d27d3b4b08b601.md)

[**Sovereign**](Sovereign%20ec44ae62787c4a21ba554956dc9b6133.md)

[**ZK Stack**](ZK%20Stack%208fb4a1260d884513bff0a0b6c70b964b.md)

[**Starknet Slush**](https://www.notion.so/Starknet-Slush-7212a617285843c9ae3ce21826fbe29c?pvs=21)

[**Stackr**](https://www.notion.so/Stackr-c629fca3105e4457921c9cb29e80319b?pvs=21)

[**Cartesi**](Cartesi%20a5dc22f1cf334601851bd4b301a59651.md)

[**Opside**](Opside%205f8ef2be16eb4351937f16b7926746ff.md)

[**Berachain**](https://www.notion.so/Berachain-68b60a65f5e342cabef2b82d863095b1?pvs=21)

> **No-Code Deployment**
> 

[**Eclipse**](Eclipse%202e7660ff2c764c429ce7b0814761686b.md)

[**AltLayer**](AltLayer%207671ad3cb13040a69b91ebba9386d6ae.md)

[**Caldera**](Caldera%20dab5daeb91414d34a43e11e7904068c9.md)

[**Conduit**](Conduit%200bf36a8c9c984d07943ec93d5c129d78.md)

[**Artesi**](https://www.notion.so/Artesi-96d66c36866f47d3b6cc883ddc1ca135?pvs=21)

> **Shared Sequencer**
> 

[OP Stack](OP%20Stack%20a0c4bad98dc042db87272cf107a9f17c.md)

[**Dymension**](Dymension%20fca81017f6a64d1fac362e6f56e990bd.md)

[**Espresso**](Espresso%20423bd9cb0bc44028a4e0a3bbb3ec0e2b.md)

[**Flashbots Suave**](Flashbots%20Suave%20bdcb0bb65efa4199a7845e1fe015ef36.md)

[**Saga**](Saga%20174dca18819e485b8b31d8e0c014a472.md)

### **Eclipse Ecosystem**

[`Website`](https://www.eclipse.builders/)   [`Twitter`](https://twitter.com/EclipseFND)   [`Discord`](https://discord.com/invite/PVcbxdqj6r)

**An overview of the Projects in the Eclipse ecosystem.**

[**Analysis**](Eclipse%208cde5298b68e4399a17e8c14cce2cb3c.md)   [**All](All%207ba2758196c24f4db27c354ff2559324.md)   [Wallet](Wallet%20443ef7316f96437a942afc529367aa6f.md)   [Bridge](Bridge%2045b6c2b8c26d4a22974205e456eff739.md)   [DEX](DEX%20bcb349e4e9304bb99fa06e68c045ce7d.md)   [DeFi](DeFi%2000be30e14bde4915bdcbce7e44d087cd.md)   [NFT Trade](NFT%20Trade%207213525d5f5e488cb5f07bb37c924f62.md)   [NFT](NFT%207d9357a8b7574524a0ea7de292c55178.md)   [Game](Game%20737ad142985d4a218a16400d3c0fd370.md)   [Social](Social%2078212478993240e488635b28c5bdb004.md)   [Infra Tool](Infra%20Tool%2095201b905cff42e194d6d7d95db2c036.md)**

### Description

TBD

### **State Vali**dation

- **TBD**
TBD
    
    `TBD`
    
- **TBD**
- **TBD**

### Data Availability

- **On chain
Ethereum DA**

### Upgradeability

- **TBD**
    
    `TBD`
    

### Operator

- **Single Sequencer (existing)**
    - **Censorship Resistance**
    Users can force any transaction: Allows the users to circumvent censorship by interacting with the smart contract directly.
    - **Sequencer Failure: Transact using Layer1**
    If the primary sequencer goes down, the user is able to submit a transaction through Layer1 and force its inclusion on Layer2.
    
    **`MEV can be extracted if the operator exploits their centralized position and frontruns user transactions.`**
    
- **TBD**

### Environments

- **Ethereum VM**

### Technical Decentralization

- **TBD**
    - **TBD**
        
        TBD
        
    - **TBD**
        
        TBD
        
- **TBD**
    - **TBD**
    TBD
    - **TBD**
    TBD
    - **TBD**
    TBD
    ****

[All](All%207ba2758196c24f4db27c354ff2559324.md)

[Wallet](Wallet%20443ef7316f96437a942afc529367aa6f.md)

[Bridge](Bridge%2045b6c2b8c26d4a22974205e456eff739.md)

[DEX](DEX%20bcb349e4e9304bb99fa06e68c045ce7d.md)

[DeFi](DeFi%2000be30e14bde4915bdcbce7e44d087cd.md)

[NFT Trade](NFT%20Trade%207213525d5f5e488cb5f07bb37c924f62.md)

[NFT](NFT%207d9357a8b7574524a0ea7de292c55178.md)

[Game](Game%20737ad142985d4a218a16400d3c0fd370.md)

[Social](Social%2078212478993240e488635b28c5bdb004.md)

[Infra Tool](Infra%20Tool%2095201b905cff42e194d6d7d95db2c036.md)