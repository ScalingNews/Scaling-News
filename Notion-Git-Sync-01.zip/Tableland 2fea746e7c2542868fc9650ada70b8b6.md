# Tableland

Category: Web3 Relational Database
Rating Index: ⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum Nova, Arbitrum One, OP Mainnet
Link | Click the Link Text: https://twitter.com/tableland__   https://discord.com/invite/dc8EBEhGbg   https://tableland.xyz/
 Raised: $ 9.5M
Investor: A.Capital, BlueYard, CoinFund, Coinbase, Collaborative, Multicoin, Protocol Labs
List: Infra