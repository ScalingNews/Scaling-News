# PixelSwap

Category: AMM DEX
Rating Index: ⭐️⭐️⭐️
Ecosystem: Arbitrum One, Base, Linea, Scroll, Taiko, opBNB, zkSync Era
Link | Click the Link Text: https://twitter.com/PixelSwapFi   https://discord.com/invite/kQ5NSZMW58   https://pixelswap.xyz/
Token: PIXEL
List: DEX