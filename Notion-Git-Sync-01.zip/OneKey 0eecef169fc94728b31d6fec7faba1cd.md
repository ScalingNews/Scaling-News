# OneKey

Category: Hardware Wallet
Rating Index: ⭐️⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum Nova, Arbitrum One, Linea, OP Mainnet, Polygon zkEVM, Scroll, zkSync Era
Link | Click the Link Text: https://twitter.com/OneKeyHQ   https://discord.com/invite/nwUJaTzjzv   https://onekey.so/
 Raised: $ 20M
Investor:  Ribbit Capital, Coinbase, Dragonfly Capital, Ethereal Ventures, Folius Ventures, Framework, IOSG Ventures, Sky9 Capital
List: Wallet