# Sperax

Category: Stablecoin Yield, Yield Optimizer
Rating Index: ⭐️⭐️⭐️
Ecosystem: Arbitrum One
Link | Click the Link Text: https://twitter.com/SperaxUSD   https://discord.com/invite/Tt4p8BvZ   https://sperax.io/
Token: SPA
List: DeFi