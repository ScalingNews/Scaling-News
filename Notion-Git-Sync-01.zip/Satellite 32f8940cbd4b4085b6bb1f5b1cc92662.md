# Satellite

Category: CrossChain Bridge
Rating Index: ⭐️⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One, Axelar, Base, Linea, OP Mainnet
Link | Click the Link Text: https://twitter.com/Axl_Satellite   https://discord.com/invite/aRZ3Ra6f7D   https://satellite.money/
Investor: Axelar
List: Bridge