# EthStorage

Category: dStorage
Rating Index: ⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One
Link | Click the Link Text: https://twitter.com/EthStorage   https://t.me/ethstorage   https://ethstorage.io/
 Raised: $ 7M
Investor: Foresight Ventures, Gate Labs, SevenX Ventures, Sky9 Capital, dao5
List: Infra