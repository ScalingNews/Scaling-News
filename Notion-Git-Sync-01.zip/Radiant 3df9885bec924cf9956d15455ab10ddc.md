# Radiant

Category: Omnichain Lending
Rating Index: ⭐️⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One, LayerZero
Link | Click the Link Text: https://twitter.com/RDNTCapital   https://discord.com/invite/radiantcapital   https://app.radiant.capital/#/markets
 Raised: $ 10M
Investor: Binance Labs
Token: RDNT
List: DeFi