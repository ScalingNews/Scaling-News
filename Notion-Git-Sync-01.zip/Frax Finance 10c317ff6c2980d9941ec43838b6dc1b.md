# Frax Finance

Category: Fractional Stablecoin, Liquid Staking Token
Rating Index: ⭐️⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One, EigenLayer, OP Mainnet
Link | Click the Link Text: https://x.com/fraxfinance   https://discord.com/invite/fraxfinance   https://www.frax.com/
Investor: Crypto.com, Dragonfly Capital, Electric Capital, Galaxy Digital, Mechanism Capital, Multicoin, ParaFi Capital, Robot Ventures, Tribe Capital
Token: FXS/sfrxETH
List: DeFi