# Split Protocol

Category: MEV Protection
Rating Index: ⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One
Link | Click the Link Text: https://twitter.com/SplitProtocol   https://discord.com/invite/Qvn4t7x6VY   https://splitex.app/
List: Infra