# Gains Network

Category: FX Market, Perpetual Market
Rating Index: ⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One, Polygon zkEVM
Link | Click the Link Text: https://twitter.com/GainsNetwork_io   https://discord.com/invite/gains-network   https://gainsnetwork.io/
Token: GNS
List: DEX