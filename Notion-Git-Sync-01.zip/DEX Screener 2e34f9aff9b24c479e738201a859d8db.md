# DEX Screener

Category: DEX Pairs Charts
Rating Index: ⭐️⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum Nova, Arbitrum One, Base, Ethereum, Kakarot, Linea, Mantle, OP Mainnet, Polygon, Polygon zkEVM, Scroll, Starknet, Taiko, Zora Network, opBNB, zkSync Era, zkSync Lite
Link | Click the Link Text: https://twitter.com/dexscreener   https://discord.com/invite/ARbh55A472   https://dexscreener.com/
List: Infra