# Overtime

Category: Prediction Market
Rating Index: ⭐️⭐️
Ecosystem: Arbitrum One, OP Mainnet
Link | Click the Link Text: https://twitter.com/OvertimeMarkets   http://discord.gg/thales   https://overtimemarkets.xyz/
List: DEX