# Dank protocol

Category: Lending
Rating Index: ⭐️⭐️
Ecosystem: Arbitrum One
Link | Click the Link Text: https://twitter.com/dank_protocol   https://discord.com/invite/FzXRbHFWf5   https://www.dank-protocol.com/#/home
Token: DANK
List: DeFi