# Aark Digital

Category: Perpetual Market
Rating Index: ⭐️⭐️⭐️
Ecosystem: Arbitrum One
Link | Click the Link Text: https://twitter.com/Aark_Digital   https://discord.com/invite/aarkdigital   https://aark.digital/
List: DEX