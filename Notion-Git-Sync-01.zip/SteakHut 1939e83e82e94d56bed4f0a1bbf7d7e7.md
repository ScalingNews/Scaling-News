# SteakHut

Category: Liquidity Manager
Rating Index: ⭐️⭐️⭐️
Ecosystem: Arbitrum One
Link | Click the Link Text: https://twitter.com/steakhut_fi   https://discord.com/invite/steakhut   https://www.steakhut.finance/
Token: STEAK
List: DeFi