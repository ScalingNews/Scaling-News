# PARSIQ

Category: OnChain Data Indexing
Rating Index: ⭐️⭐️⭐️⭐️
Ecosystem: Arbitrum One
Link | Click the Link Text: https://twitter.com/parsiq_net   https://discord.com/invite/PMWaxp5dFp   https://www.parsiq.net/
Token: PRQ
List: Infra