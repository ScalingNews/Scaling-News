# OP Stack

> **RaaS Framework**
> 

[Arbitrum Orbit](Arbitrum%20Orbit%20e21bddc4d495401b830819fe3e8e1000.md)

[**Rollkit**](https://www.notion.so/Rollkit-1659ae96b3224453a23e14e9c5995779?pvs=21)

[**Fuel**](Fuel%2010ef831a877f49659a8b419d401c8bac.md)

[**EigenLayer**](EigenLayer%202228903b7d524a8ca8a4795d17701ad2.md)

[**Celestia**](Celestia%20b9a3141a8c1149fe8270f256f6b8f886.md)

[**Avail**](Avail%20ddc337c43f0d41c595d27d3b4b08b601.md)

[**Sovereign**](Sovereign%20ec44ae62787c4a21ba554956dc9b6133.md)

[**ZK Stack**](ZK%20Stack%208fb4a1260d884513bff0a0b6c70b964b.md)

[**Starknet Slush**](https://www.notion.so/Starknet-Slush-7212a617285843c9ae3ce21826fbe29c?pvs=21)

[**Stackr**](https://www.notion.so/Stackr-c629fca3105e4457921c9cb29e80319b?pvs=21)

[**Cartesi**](Cartesi%20a5dc22f1cf334601851bd4b301a59651.md)

[**Opside**](Opside%205f8ef2be16eb4351937f16b7926746ff.md)

[**Berachain**](https://www.notion.so/Berachain-68b60a65f5e342cabef2b82d863095b1?pvs=21)

> **No-Code Deployment**
> 

[**Eclipse**](Eclipse%202e7660ff2c764c429ce7b0814761686b.md)

[**AltLayer**](AltLayer%207671ad3cb13040a69b91ebba9386d6ae.md)

[**Caldera**](Caldera%20dab5daeb91414d34a43e11e7904068c9.md)

[**Conduit**](Conduit%200bf36a8c9c984d07943ec93d5c129d78.md)

[**Artesi**](https://www.notion.so/Artesi-96d66c36866f47d3b6cc883ddc1ca135?pvs=21)

> **Shared Sequencer**
> 

[OP Stack](OP%20Stack%20a0c4bad98dc042db87272cf107a9f17c.md)

[**Dymension**](Dymension%20fca81017f6a64d1fac362e6f56e990bd.md)

[**Espresso**](Espresso%20423bd9cb0bc44028a4e0a3bbb3ec0e2b.md)

[**Flashbots Suave**](Flashbots%20Suave%20bdcb0bb65efa4199a7845e1fe015ef36.md)

[**Saga**](Saga%20174dca18819e485b8b31d8e0c014a472.md)

### OP Stack **Ecosystem**

[`Website`](https://app.optimism.io/superchain)   [`Twitter`](https://twitter.com/optimismFND)   [`Discord`](https://discord-gateway.optimism.io/)   [`Github`](https://github.com/ethereum-optimism)

**An overview of the Projects in the OP Stack ecosystem.**

[**Analysis**](OP%20Stack%202da96ec25e7f44bd87b7be2e8f5fd5a3.md)   [**All](All%20629f6d97737942389cc98ab5ad496c93.md)   [Wallet](Wallet%20530c91e2c8e64a4ab0a7a773146fb885.md)   [Bridge](Bridge%201cddef5a3cc34bb180ec1a084999e61f.md)   [DEX](DEX%2049de70bf3f864813956f471069601d66.md)   [DeFi](DeFi%20a1b46f61ac7141cb8eb1db3808aeeae0.md)   [NFT Trade](NFT%20Trade%20fc1cc5ee99a246289e98fdbe205fbca2.md)   [NFT](NFT%2021973bd7c0c54825a52ec1368f2eabb6.md)   [Game](Game%204f0e9511381e434aacb799dd70082438.md)   [Social](Social%20e0c873a997344bf4808b66a336483a4e.md)   [Infra Tool](Infra%20Tool%200aebe99204614606b98f113d6597465b.md)**

### Description

The [OP Stack](https://stack.optimism.io/) is the standardized, shared, and open-source development stack that powers Optimism, maintained by the Optimism [Collective](https://community.optimism.io/docs/governance/#).

Optimism [Bedrock](https://stack.optimism.io/docs/releases/bedrock/) is the current iteration of the OP Stack. The Bedrock release provides the tools for launching a production-quality Optimistic Rollup blockchain. At this point in time, the APIs for the different layers of the OP Stack are still tightly coupled to this Rollup configuration of the stack.

The OP Stack of today was built to support the Optimism [Superchain](https://stack.optimism.io/docs/understand/explainer/), a proposed network of L2s that share security, communication layers, and a common development stack (the OP Stack itself). The Bedrock release of the OP Stack makes it easy to spin up an L2 that will be compatible with the Superchain when it launches.

It is possible to modify components of the OP Stack to build novel L2 systems. If you're interested in experimenting with the OP Stack, check out the [OP Stack Hacks](https://stack.optimism.io/docs/build/hacks/).

### **State Vali**dation

- **Attestation Proof (existing)**
Fault proofs do not meaningfully improve the security of a system if that system can be upgraded within the 7 day challenge window (”fast upgrade keys”). A system with fast upgrade keys, such as Optimism, is fully dependent on the upgrade keys for security.
    
    **`Assets can be stolen if an invalid state root is submitted to the system (CRITICAL).`**
    
- **Fault Proof (developing)**
- **Validity Proof (proposed)**

### Data Availability

- **On chain
Ethereum DA**

### Upgradeability

- **Fast Upgrade Keys - Anonymous Multisig Manage**
    
    **`The code that secures the system can be changed arbitrarily.`**
    

### Operator

- **Single Sequencer (existing)**
    - **Censorship Resistance**
    Users can force any transaction: Allows the users to circumvent censorship by interacting with the smart contract directly.
    - **Sequencer Failure: Transact using Layer1**
    If the primary sequencer goes down, the user is able to submit a transaction through Layer1 and force its inclusion on Layer2.
    
    **`MEV can be extracted if the operator exploits their centralized position and frontruns user transactions.`**
    
- **PoA Sequencer (proposed)**

### Environments

- **Ethereum VM**

### Technical Decentralization

- **Baseline Decentralization**
    - **Permissionless Output**
        
        Create Proofers Network: Withdraw assets from L2 to L1 permissionlessly.
        
    - **Bridge Decentralization**
        
        Create Security Council: Upgradeability: Least 7 days delay.
        
- **Cannon Fault Proof**
    - **Cannon Fault Proof Program**
    Implementing a fault proof program that executes the L2 state transition so that outputs can be program matically verified on L1 is a precursor to full fault proof activation.
    - **Cannon Fault Proof VM**
    Making it possible to execute the fault proof program on L1 is another precursor to full fault proof activation.
    - **Dispute Game Integration**
    This step would enable Cannon to prove faults on L1. With this milestone, Optimism will be fully fault provable. Once additional fault proof implementations are ready, the attestor network can be phased out.
    ****

[All](All%20629f6d97737942389cc98ab5ad496c93.md)

[Wallet](Wallet%20530c91e2c8e64a4ab0a7a773146fb885.md)

[Bridge](Bridge%201cddef5a3cc34bb180ec1a084999e61f.md)

[DEX](DEX%2049de70bf3f864813956f471069601d66.md)

[DeFi](DeFi%20a1b46f61ac7141cb8eb1db3808aeeae0.md)

[NFT Trade](NFT%20Trade%20fc1cc5ee99a246289e98fdbe205fbca2.md)

[NFT](NFT%2021973bd7c0c54825a52ec1368f2eabb6.md)

[Game](Game%204f0e9511381e434aacb799dd70082438.md)

[Social](Social%20e0c873a997344bf4808b66a336483a4e.md)

[Infra Tool](Infra%20Tool%200aebe99204614606b98f113d6597465b.md)